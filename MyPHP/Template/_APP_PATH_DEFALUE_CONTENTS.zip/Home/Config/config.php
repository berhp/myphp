<?php 
//自定义HOME子模块下的配置$Key=>$value
return array(

);