<?php
namespace Home\Model;
use MyPHP\Model;
class TestModel extends Model{
    public function _init(){

    }


}

