<?php 
/**
 * 演示 - 所有APP项目的公共model
 */
namespace Model;
use MyPHP\Model;
class DemoModel extends Model{
	
	/**
	 * @example
	   $d = new \Model\DemoModel;
	   $r = $d->demo();
	   var_dump($r);
	 */
	public function demo(){
		return array(
				'demo'  => 11,
				'demo2' => 22,
		);
	}
	
	/**
	 * @example
	 $r = \Model\DemoModel::demo_static();
	 var_dump($r);
	 */
	static public function demo_static(){
		return array(
				'sdemo'  => 11,
				'sdemo2' => 22,
		);
	}	
	
	
	
	
	
	
}