<?php 
//公共的-所有api自定义函数.txt
