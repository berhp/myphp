<?php 
//自定义子项目的配置$key=>$value
return array(

);