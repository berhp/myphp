<?php 
/**
 * 演示-接口控制器 - 继承 自定义 继承类: \Api\BaseApiController.class.php
 */
namespace Home\v1\Controller\Home;
use Home\v1\Model\DemoModel;
class Index2Api extends \Api\BaseApiController {
	
	public function index(){
		$data = array(
				'Welcome' => 'api demo2',
				'Version' => MyPHP_VERSION,
				'url' 	  => __URL__ .'api.php/Home/v1/Home/Index/index',
		);
		$this->ajaxReturn($data);
	}
	
	public function db_demo(){
		$r = \Home\v1\Model\DemoModel::demo_static();
		p($r);
		
		$model = new DemoModel();
		$r = $model->demo();
		p($r);
	}
	
	/**
	 * 查看当前所有加载文件和配置
	 */
	public function stats(){
		\Log\get::stats();
	}
	
	/**
	 * phpinfo
	 */
	public function phpinfo(){
		phpinfo();
	}

	
	/**
	 * 演示用户登录成功回返token
	 * @example  api.php/Home/v1/Home/index2/login?uid=1
	 */
	public function login(){
		$uid = I('uid', 0);
		$data = array(
				'name'  => '演示用户信息',
				'token' => $this->create_token($uid),
		);
		$r = showData($data);
		$this->jsonOutput($r);
	}
	
	/**
	 * 演示 请求用户资料,token检验
	 * @example  api.php/Home/v1/Home/index2/checktoken?token=MV8xNTA2NzM4NTYxX2YyMDY3ZTRhZGM5ZDUwMWU3ZDhjODc3YWYzYzRkMDAw&uid=1
	 */
	public function checktoken(){
		$this->checkApiToken();
		$data = array(
				'name'  => '演示用户信息',
				'sex' 	=> '性别',
		);
		$r = showData($data);
		$this->jsonOutput($r);
	}
	
}