<?php 
/**
 * 演示-接口控制器
 */
namespace Home\v1\Controller\Home;
use MyPHP\Api;
use Home\v1\Model\DemoModel;
class IndexApi extends Api{
	
	public function index(){
		$data = array(
				'Welcome' => 'api demo',
				'Version' => MyPHP_VERSION,
				'url' 	  => __URL__ .'api.php/Home/v1/Home/Index/index',
		);
		$this->ajaxReturn($data);
	}
	
	public function db_demo(){
		$r = \Home\v1\Model\DemoModel::demo_static();
		p($r);
		
		$model = new DemoModel();
		$r = $model->demo();
		p($r);
	}
	
	/**
	 * 查看当前所有加载文件和配置
	 */
	public function stats(){
		\Log\get::stats();
	}
	
	/**
	 * phpinfo
	 */
	public function phpinfo(){
		phpinfo();
	}

}