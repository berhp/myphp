<?php 
/**
 * 演示-DemoModel
 */
namespace Home\v1\Model;
use MyPHP\Model;
class DemoModel extends Model{
	
	/**
	 * @example
		 $d = new \Home\v1\Model\DemoModel;
		 $r = $d->demo();
		 var_dump($r);
	 */
	public function demo(){
		return array(
				'name' => 1,
				'pass' => '11',
		);
	}
	
	/**
	 * @example
		 $r = \Home\v1\Model\DemoModel::demo_static();
		 var_dump($r);
	 */
	static public function demo_static(){
		return array(
				'name2' => 12,
				'pass2' => '112',
		);		
	}
	
	/**
	 * sql演示
	 */
	public function db(){
		$sql = "";
		$r = M('')->query($sql);
		return $r;
	}
	
}