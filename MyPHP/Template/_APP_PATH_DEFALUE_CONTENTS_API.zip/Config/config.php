<?php 
//自定义公共的配置$key=>$value
return array(
		'demo_k' => 'demo_v',
		
		/* 模板设置 */
		'template' => array(
				'filePath' => APP_PATH.'/Template/', 	//模板所在目录
				'404' 		=> '404.tpl', 				//404错误文件, 对应设置的“模板目录”下
		),
		
);